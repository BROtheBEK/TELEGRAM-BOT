import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import bcrypt from "bcrypt";
import { insertUserSchema, insertProductSchema, insertOrderSchema, insertNewsSchema, insertCommentSchema } from "@shared/schema";
import { z } from "zod";
import { eskizSMS } from "./sms";

const SALT_ROUNDS = 10;

// Eskiz.uz SMS service
const sendSMS = async (phone: string, message: string): Promise<boolean> => {
  try {
    const success = await eskizSMS.sendSMS(phone, message);
    if (success) {
      console.log(`SMS muvaffaqiyatli yuborildi: ${phone}`);
    } else {
      console.log(`SMS yuborishda xato: ${phone}`);
    }
    return success;
  } catch (error) {
    console.error('SMS yuborish xatosi:', error);
    return false;
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/send-sms", async (req, res) => {
    try {
      const { phone } = req.body;
      if (!phone) {
        return res.status(400).json({ message: "Phone number is required" });
      }

      // 1 daqiqalik limit tekshirish
      const recentSms = await storage.getSmsVerification(phone, "");
      if (recentSms && new Date().getTime() - new Date(recentSms.createdAt).getTime() < 60000) {
        return res.status(429).json({ 
          message: "SMS qayta yuborish uchun 1 daqiqa kutishingiz kerak",
          remainingTime: 60 - Math.floor((new Date().getTime() - new Date(recentSms.createdAt).getTime()) / 1000)
        });
      }

      const code = Math.floor(100000 + Math.random() * 900000).toString();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

      await storage.createSmsVerification({
        phone,
        code,
        expiresAt,
      });

      // Eskiz.uz test matnidan foydalanish
      const testMessage = `Bu Eskiz dan test. Tasdiqlash kodi: ${code}`;
      const success = await sendSMS(phone, testMessage);
      
      if (!success) {
        return res.status(500).json({ message: "SMS yuborishda xatolik yuz berdi" });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error('SMS yuborish xatosi:', error);
      res.status(500).json({ message: "SMS yuborishda xatolik yuz berdi" });
    }
  });

  app.post("/api/auth/verify-sms", async (req, res) => {
    try {
      const { phone, code } = req.body;
      if (!phone || !code) {
        return res.status(400).json({ message: "Phone and code are required" });
      }

      const verification = await storage.getSmsVerification(phone, code);
      if (!verification || verification.expiresAt < new Date()) {
        return res.status(400).json({ message: "Invalid or expired code" });
      }

      await storage.updateSmsVerification(verification.id, { isVerified: true });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Verification failed" });
    }
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const { phone, password } = req.body;
      
      const userSchema = insertUserSchema.extend({
        password: z.string().min(8, "Password must be at least 8 characters"),
      });
      
      const validatedData = userSchema.parse({ phone, password });

      // Check if user already exists
      const existingUser = await storage.getUserByPhone(phone);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      // Verify SMS was confirmed
      const verification = await storage.getSmsVerification(phone, "");
      if (!verification?.isVerified) {
        return res.status(400).json({ message: "Phone not verified" });
      }

      const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
      const user = await storage.createUser({
        phone,
        password: hashedPassword,
        role: "customer",
      });

      res.json({ user: { id: user.id, phone: user.phone, role: user.role } });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "Registration failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { phone, password } = req.body;
      if (!phone || !password) {
        return res.status(400).json({ message: "Phone and password are required" });
      }

      const user = await storage.getUserByPhone(phone);
      if (!user) {
        return res.status(400).json({ message: "Invalid credentials" });
      }

      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(400).json({ message: "Invalid credentials" });
      }

      res.json({ user: { id: user.id, phone: user.phone, role: user.role, firstName: user.firstName, lastName: user.lastName } });
    } catch (error) {
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Products routes
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const product = await storage.getProduct(id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  app.post("/api/products", async (req, res) => {
    try {
      const validatedData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(validatedData);
      res.json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "Failed to create product" });
    }
  });

  app.put("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertProductSchema.partial().parse(req.body);
      const product = await storage.updateProduct(id, validatedData);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "Failed to update product" });
    }
  });

  app.delete("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteProduct(id);
      if (!success) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  // Orders routes
  app.get("/api/orders", async (req, res) => {
    try {
      const { status, userId, deliveryPersonId } = req.query;
      let orders;
      
      if (status) {
        const statusList = (status as string).split(',');
        if (statusList.length > 1) {
          // Handle multiple statuses for delivery personnel
          const allOrders = await storage.getOrders();
          orders = allOrders.filter(order => statusList.includes(order.status));
        } else {
          orders = await storage.getOrdersByStatus(status as string);
        }
      } else if (userId) {
        orders = await storage.getOrdersByUser(parseInt(userId as string));
      } else {
        orders = await storage.getOrders();
      }

      // Filter by delivery person if specified
      if (deliveryPersonId) {
        orders = orders.filter(order => order.deliveryPersonId === parseInt(deliveryPersonId as string));
      }
      
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.post("/api/orders", async (req, res) => {
    try {
      const validatedData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(validatedData);
      
      // Send SMS notification
      const user = await storage.getUser(order.userId);
      if (user) {
        await sendSMS(user.phone, "Buyurtmangiz qabul qilindi va ko'rib chiqilmoqda.");
      }
      
      res.json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "Failed to create order" });
    }
  });

  app.put("/api/orders/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertOrderSchema.partial().parse(req.body);
      const order = await storage.updateOrder(id, validatedData);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }

      // Send SMS notifications based on status
      const user = await storage.getUser(order.userId);
      if (user) {
        let message = "";
        switch (order.status) {
          case "accepted":
            message = "Buyurtmangiz qabul qilindi";
            break;
          case "preparing":
            message = "Buyurtmangiz tayyorlanmoqda";
            break;
          case "delivery":
            message = "Buyurtmangiz yo'lga chiqdi";
            break;
          case "delivered":
            message = "Buyurtmangiz yetkazib berildi";
            break;
          case "returned":
            message = "Buyurtmangiz qaytarildi";
            break;
        }
        if (message) {
          await sendSMS(user.phone, message);
        }
      }
      
      res.json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "Failed to update order" });
    }
  });

  // News routes
  app.get("/api/news", async (req, res) => {
    try {
      const news = await storage.getNews();
      res.json(news);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch news" });
    }
  });

  app.post("/api/news", async (req, res) => {
    try {
      const validatedData = insertNewsSchema.parse(req.body);
      const news = await storage.createNews(validatedData);
      res.json(news);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "Failed to create news" });
    }
  });

  app.delete("/api/news/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteNews(id);
      if (!success) {
        return res.status(404).json({ message: "News not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete news" });
    }
  });

  // Comments routes
  app.get("/api/products/:id/comments", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const comments = await storage.getCommentsByProduct(productId);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  app.post("/api/products/:id/comments", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const { content, userId } = req.body;
      
      const validatedData = insertCommentSchema.parse({
        productId,
        userId,
        content,
      });
      
      const comment = await storage.createComment(validatedData);
      res.json(comment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "Failed to create comment" });
    }
  });

  // Admin routes for creating delivery personnel and operators
  app.post("/api/admin/users", async (req, res) => {
    try {
      const { phone, password, role, firstName, lastName, birthYear } = req.body;
      
      const userSchema = insertUserSchema.extend({
        password: z.string().min(8),
        role: z.enum(["delivery", "operator", "admin"]),
      });
      
      const validatedData = userSchema.parse({
        phone,
        password,
        role,
        firstName,
        lastName,
        birthYear,
      });

      const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
      const user = await storage.createUser({
        ...validatedData,
        password: hashedPassword,
      });

      res.json({ user: { id: user.id, phone: user.phone, role: user.role, firstName: user.firstName, lastName: user.lastName } });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
