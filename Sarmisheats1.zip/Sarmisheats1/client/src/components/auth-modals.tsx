import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/hooks/use-language";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function AuthModals() {
  const { 
    isLoginModalOpen, 
    isSignupModalOpen, 
    closeLoginModal, 
    closeSignupModal, 
    login 
  } = useAuth();
  const { t } = useLanguage();
  const { toast } = useToast();

  const [signupStep, setSignupStep] = useState(1);
  const [signupData, setSignupData] = useState({
    phone: "",
    code: "",
    password: "",
    confirmPassword: "",
  });
  const [countdown, setCountdown] = useState(0);

  const sendSmsMutation = useMutation({
    mutationFn: async (phone: string) => {
      return apiRequest("POST", "/api/auth/send-sms", { phone });
    },
    onSuccess: () => {
      setSignupStep(2);
      setCountdown(60);
      const timer = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      toast({ title: t('smsSent'), description: t('enterCode') });
    },
    onError: (error: any) => {
      if (error.status === 429) {
        const remainingTime = error.remainingTime || 60;
        setCountdown(remainingTime);
        const timer = setInterval(() => {
          setCountdown((prev) => {
            if (prev <= 1) {
              clearInterval(timer);
              return 0;
            }
            return prev - 1;
          });
        }, 1000);
        toast({ 
          title: "Kutish kerak", 
          description: `SMS qayta yuborish uchun ${remainingTime} soniya kutishingiz kerak`, 
          variant: "destructive" 
        });
      } else {
        toast({ title: t('error'), description: t('smsError'), variant: "destructive" });
      }
    },
  });

  const verifySmsMutation = useMutation({
    mutationFn: async ({ phone, code }: { phone: string; code: string }) => {
      return apiRequest("POST", "/api/auth/verify-sms", { phone, code });
    },
    onSuccess: () => {
      setSignupStep(3);
      toast({ title: t('verified'), description: t('createPassword') });
    },
    onError: () => {
      toast({ title: t('error'), description: t('invalidCode'), variant: "destructive" });
    },
  });

  const registerMutation = useMutation({
    mutationFn: async ({ phone, password }: { phone: string; password: string }) => {
      return apiRequest("POST", "/api/auth/register", { phone, password });
    },
    onSuccess: async (response) => {
      const userData = await response.json();
      login(userData.user);
      closeSignupModal();
      resetSignupForm();
      toast({ title: t('registered'), description: t('welcomeMessage') });
    },
    onError: () => {
      toast({ title: t('error'), description: t('registrationError'), variant: "destructive" });
    },
  });

  const loginMutation = useMutation({
    mutationFn: async ({ phone, password }: { phone: string; password: string }) => {
      return apiRequest("POST", "/api/auth/login", { phone, password });
    },
    onSuccess: async (response) => {
      const userData = await response.json();
      login(userData.user);
      closeLoginModal();
      toast({ title: t('loggedIn'), description: t('welcomeBack') });
    },
    onError: () => {
      toast({ title: t('error'), description: t('loginError'), variant: "destructive" });
    },
  });

  const resetSignupForm = () => {
    setSignupStep(1);
    setSignupData({ phone: "", code: "", password: "", confirmPassword: "" });
  };

  const handleSendSms = (e: React.FormEvent) => {
    e.preventDefault();
    if (!signupData.phone.trim()) {
      toast({ title: t('error'), description: t('phoneRequired'), variant: "destructive" });
      return;
    }
    sendSmsMutation.mutate(signupData.phone);
  };

  const handleVerifySms = (e: React.FormEvent) => {
    e.preventDefault();
    if (!signupData.code.trim()) {
      toast({ title: t('error'), description: t('codeRequired'), variant: "destructive" });
      return;
    }
    verifySmsMutation.mutate({ phone: signupData.phone, code: signupData.code });
  };

  const handleCreatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (signupData.password.length < 8) {
      toast({ title: t('error'), description: t('passwordTooShort'), variant: "destructive" });
      return;
    }
    
    if (signupData.password !== signupData.confirmPassword) {
      toast({ title: t('error'), description: t('passwordsNotMatch'), variant: "destructive" });
      return;
    }
    
    registerMutation.mutate({ phone: signupData.phone, password: signupData.password });
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget as HTMLFormElement);
    const phone = formData.get("phone") as string;
    const password = formData.get("password") as string;
    
    if (!phone || !password) {
      toast({ title: t('error'), description: t('fillAllFields'), variant: "destructive" });
      return;
    }
    
    loginMutation.mutate({ phone, password });
  };

  return (
    <>
      {/* Login Modal */}
      <Dialog open={isLoginModalOpen} onOpenChange={closeLoginModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">{t('login')}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <Label htmlFor="login-phone">{t('phoneNumber')}</Label>
              <Input 
                id="login-phone"
                name="phone"
                type="tel" 
                placeholder="+998 90 123 45 67"
                required
              />
            </div>
            <div>
              <Label htmlFor="login-password">{t('password')}</Label>
              <Input 
                id="login-password"
                name="password"
                type="password" 
                placeholder={t('enterPassword')}
                required
              />
            </div>
            <Button 
              type="submit" 
              className="w-full"
              disabled={loginMutation.isPending}
            >
              {loginMutation.isPending ? t('loggingIn') : t('login')}
            </Button>
            <div className="text-center">
              <button 
                type="button"
                onClick={() => {
                  closeLoginModal();
                  // Open signup modal - this would be handled by auth context
                }}
                className="text-primary hover:text-blue-700 transition-colors"
              >
                {t('noAccount')}
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Signup Modal */}
      <Dialog open={isSignupModalOpen} onOpenChange={() => { closeSignupModal(); resetSignupForm(); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">{t('signup')}</DialogTitle>
          </DialogHeader>

          {/* Step 1: Phone Number */}
          {signupStep === 1 && (
            <form onSubmit={handleSendSms} className="space-y-6">
              <div>
                <Label htmlFor="signup-phone">{t('phoneNumber')}</Label>
                <Input 
                  id="signup-phone"
                  type="tel"
                  value={signupData.phone}
                  onChange={(e) => setSignupData(prev => ({ ...prev, phone: e.target.value }))}
                  placeholder="+998 90 123 45 67"
                  required
                />
              </div>
              <Button 
                type="submit" 
                className="w-full"
                disabled={sendSmsMutation.isPending}
              >
                {sendSmsMutation.isPending ? t('sending') : t('sendSmsCode')}
              </Button>
            </form>
          )}

          {/* Step 2: SMS Verification */}
          {signupStep === 2 && (
            <form onSubmit={handleVerifySms} className="space-y-6">
              <div>
                <Label htmlFor="signup-code">{t('smsCode')}</Label>
                <Input 
                  id="signup-code"
                  type="text"
                  value={signupData.code}
                  onChange={(e) => setSignupData(prev => ({ ...prev, code: e.target.value }))}
                  placeholder="123456"
                  className="text-center text-2xl tracking-widest"
                  maxLength={6}
                  required
                />
              </div>
              <Button 
                type="submit" 
                className="w-full"
                disabled={verifySmsMutation.isPending}
              >
                {verifySmsMutation.isPending ? t('verifying') : t('verify')}
              </Button>
              <div className="text-center">
                <button 
                  type="button"
                  onClick={() => sendSmsMutation.mutate(signupData.phone)}
                  className="text-primary hover:text-blue-700 transition-colors"
                >
                  {t('resendCode')}
                </button>
              </div>
            </form>
          )}

          {/* Step 3: Create Password */}
          {signupStep === 3 && (
            <form onSubmit={handleCreatePassword} className="space-y-6">
              <div>
                <Label htmlFor="signup-password">{t('createPassword')}</Label>
                <Input 
                  id="signup-password"
                  type="password"
                  value={signupData.password}
                  onChange={(e) => setSignupData(prev => ({ ...prev, password: e.target.value }))}
                  placeholder={t('passwordMinLength')}
                  required
                />
                <p className="text-sm text-neutral-500 mt-2">{t('passwordRequirements')}</p>
              </div>
              <div>
                <Label htmlFor="signup-confirm-password">{t('confirmPassword')}</Label>
                <Input 
                  id="signup-confirm-password"
                  type="password"
                  value={signupData.confirmPassword}
                  onChange={(e) => setSignupData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                  placeholder={t('reenterPassword')}
                  required
                />
              </div>
              <Button 
                type="submit" 
                className="w-full bg-secondary hover:bg-green-600"
                disabled={registerMutation.isPending}
              >
                {registerMutation.isPending ? t('creating') : t('createAccount')}
              </Button>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
