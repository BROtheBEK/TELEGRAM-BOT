import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useCart } from "@/hooks/use-cart";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/hooks/use-language";

interface ProductGridProps {
  onProductClick: (productId: number) => void;
}

export default function ProductGrid({ onProductClick }: ProductGridProps) {
  const { data: products = [] } = useQuery({
    queryKey: ["/api/products"],
  });
  
  const { addItem } = useCart();
  const { user, openLoginModal } = useAuth();
  const { toast } = useToast();
  const { t } = useLanguage();
  const [quantities, setQuantities] = useState<{[key: number]: number}>({});

  const getQuantity = (productId: number) => quantities[productId] || 1;

  const setQuantity = (productId: number, quantity: number) => {
    if (quantity >= 1) {
      setQuantities(prev => ({ ...prev, [productId]: quantity }));
    }
  };

  const handleAddToCart = (e: React.MouseEvent, product: any) => {
    e.stopPropagation();
    
    if (!user) {
      openLoginModal();
      return;
    }

    const quantity = getQuantity(product.id);
    addItem({
      id: product.id,
      name: product.name,
      price: parseFloat(product.price),
      quantity: quantity,
      image: product.images?.[0] || "",
    });

    toast({
      title: t('addedToCart'),
      description: `${product.name} (${quantity}) ${t('addedToCartDesc')}`,
    });
  };

  if (products.length === 0) {
    return (
      <div className="text-center py-12">
        <i className="fas fa-utensils text-4xl text-neutral-300 mb-4"></i>
        <p className="text-neutral-500">{t('noProductsAvailable')}</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6 lg:gap-8">
      {products.map((product: any, index: number) => (
        <Card
          key={product.id}
          className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 cursor-pointer"
          onClick={() => onProductClick(product.id)}
        >
          {product.images?.[0] && (
            <img 
              src={product.images[0]} 
              alt={product.name}
              className="w-full h-40 sm:h-48 object-cover"
            />
          )}
          <CardContent className="p-3 sm:p-4 lg:p-6">
            <h3 className="text-lg sm:text-xl font-semibold text-neutral-900 mb-2 line-clamp-1">
              {product.name}
            </h3>
            <p className="text-sm sm:text-base text-neutral-600 mb-3 sm:mb-4 line-clamp-2">
              {product.description}
            </p>
            <div className="flex flex-col gap-3">
              <div className="flex justify-between items-center">
                <span className="text-lg sm:text-xl lg:text-2xl font-bold text-primary">
                  {parseInt(product.price).toLocaleString()} {t('currency')}
                </span>
              </div>
              
              <div className="flex items-center gap-2">
                <div className="flex items-center border rounded-lg">
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setQuantity(product.id, getQuantity(product.id) - 1);
                    }}
                    className="w-8 h-8 flex items-center justify-center hover:bg-gray-100"
                  >
                    <i className="fas fa-minus text-xs"></i>
                  </button>
                  <Input
                    value={getQuantity(product.id)}
                    onChange={(e) => {
                      e.stopPropagation();
                      const val = parseInt(e.target.value) || 1;
                      setQuantity(product.id, val);
                    }}
                    className="w-12 h-8 text-center border-0 text-sm"
                    min="1"
                    type="number"
                  />
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setQuantity(product.id, getQuantity(product.id) + 1);
                    }}
                    className="w-8 h-8 flex items-center justify-center hover:bg-gray-100"
                  >
                    <i className="fas fa-plus text-xs"></i>
                  </button>
                </div>
                
                <Button 
                  onClick={(e) => handleAddToCart(e, product)}
                  className="bg-secondary text-white hover:bg-green-600 transition-colors flex-1 text-sm sm:text-base"
                  size="sm"
                >
                  <i className="fas fa-plus mr-1 sm:mr-2"></i>
                  {t('add')}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
