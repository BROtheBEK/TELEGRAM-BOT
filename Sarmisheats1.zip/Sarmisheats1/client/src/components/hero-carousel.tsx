import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/hooks/use-language";

const carouselItems = [
  {
    image: "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
    title: "fastAndDelicious",
    subtitle: "uzbekNationalDishes",
    buttonText: "orderNow",
    buttonStyle: "bg-secondary hover:bg-green-600"
  },
  {
    image: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
    title: "newTaste",
    subtitle: "freshDailyMeals",
    buttonText: "viewMore",
    buttonStyle: "bg-primary hover:bg-blue-700"
  },
  {
    image: "https://pixabay.com/get/gf0d2b4505b190b900618b8288c02c3e4dfeaccb69f129dabed075174c9769c6621e7c5aa5653105e79f3974e532032d20fdf9f0bab36439981ffd19a17860b09_1280.jpg",
    title: "in30Minutes",
    subtitle: "deliveryPromise",
    buttonText: "contact",
    buttonStyle: "bg-accent hover:bg-red-600"
  }
];

export default function HeroCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const { t } = useLanguage();

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % carouselItems.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const scrollToProducts = () => {
    document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative h-[60vh] sm:h-[70vh] lg:h-screen overflow-hidden">
      <div className="relative w-full h-full">
        {carouselItems.map((item, index) => (
          <div
            key={index}
            className={`absolute inset-0 bg-cover bg-center bg-no-repeat transition-opacity duration-1000 ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
            style={{
              backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('${item.image}')`
            }}
          >
            <div className="flex items-center justify-center h-full">
              <div className="text-center text-white px-4 sm:px-6 lg:px-4 animate-slide-up max-w-4xl">
                <h1 className="text-2xl sm:text-4xl md:text-5xl lg:text-7xl font-bold mb-3 sm:mb-4 lg:mb-6 leading-tight">
                  {t(item.title)}
                </h1>
                <p className="text-sm sm:text-lg md:text-xl lg:text-2xl mb-6 sm:mb-8 opacity-90 px-4">
                  {t(item.subtitle)}
                </p>
                <Button 
                  onClick={scrollToProducts}
                  className={`${item.buttonStyle} text-white px-4 sm:px-6 lg:px-8 py-2 sm:py-3 lg:py-4 text-sm sm:text-base lg:text-lg font-semibold transition-all transform hover:scale-105`}
                >
                  {t(item.buttonText)}
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Carousel Navigation */}
      <div className="absolute bottom-4 sm:bottom-6 lg:bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2 sm:space-x-3">
        {carouselItems.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-2 h-2 sm:w-3 sm:h-3 rounded-full bg-white transition-opacity ${
              index === currentSlide ? 'opacity-100' : 'opacity-50'
            } hover:opacity-100`}
          />
        ))}
      </div>
    </section>
  );
}
