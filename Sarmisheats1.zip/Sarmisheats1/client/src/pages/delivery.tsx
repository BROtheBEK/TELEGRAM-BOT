import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { apiRequest } from "@/lib/queryClient";

export default function Delivery() {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: allOrders = [] } = useQuery({
    queryKey: ["/api/orders", { status: "accepted" }],
    enabled: user?.role === "delivery",
  });

  const { data: myOrders = [] } = useQuery({
    queryKey: ["/api/orders", { status: "delivery", deliveryPersonId: user?.id }],
    enabled: user?.role === "delivery",
  });

  const acceptOrderMutation = useMutation({
    mutationFn: async (orderId: number) => {
      return apiRequest("PUT", `/api/orders/${orderId}`, {
        deliveryPersonId: user?.id,
        status: "delivery",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      toast({ title: "Buyurtma qabul qilindi", description: "Buyurtma yetkazish uchun qabul qilindi" });
    },
  });

  const updateOrderStatusMutation = useMutation({
    mutationFn: async ({ orderId, status }: { orderId: number; status: string }) => {
      return apiRequest("PUT", `/api/orders/${orderId}`, { status });
    },
    onSuccess: (_, { status }) => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      const message = status === "delivered" ? "Buyurtma yetkazildi" : "Buyurtma qaytarildi";
      toast({ title: message, description: "Buyurtma holati yangilandi" });
    },
  });

  if (user?.role !== "delivery") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6">
            <div className="text-center">
              <h1 className="text-2xl font-bold mb-4">Ruxsat berilmagan</h1>
              <p className="text-neutral-600 mb-4">Bu sahifaga kirish uchun yetkazuvchi huquqlari kerak</p>
              <Link href="/">
                <Button>Bosh sahifaga qaytish</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <h1 className="text-xl font-semibold text-neutral-900">Yetkazish paneli</h1>
            <div className="flex items-center space-x-4">
              <span className="text-neutral-600">Salom, {user?.firstName || user?.phone}</span>
              <Link href="/">
                <Button variant="outline">Saytga qaytish</Button>
              </Link>
              <Button variant="ghost" onClick={logout}>Chiqish</Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* All Orders Section */}
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-neutral-900">Buyurtmalar</h2>

            {allOrders.length === 0 ? (
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-8">
                    <i className="fas fa-box-open text-4xl text-neutral-300 mb-4"></i>
                    <p className="text-neutral-500">Hozircha yetkazish uchun buyurtmalar yo'q</p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              allOrders.map((order: any) => (
              <Card key={order.id} className="shadow-lg">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle>Buyurtma #{order.id}</CardTitle>
                      <p className="text-neutral-600">
                        {new Date(order.createdAt).toLocaleString()}
                      </p>
                    </div>
                    <Badge variant={order.status === "delivery" ? "default" : "secondary"}>
                      {order.status === "delivery" ? "Yetkazilmoqda" : "Kutilmoqda"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-medium text-neutral-900 mb-2">Mijoz ma'lumotlari:</h4>
                    <div className="space-y-1">
                      <div className="flex items-center">
                        <i className="fas fa-phone text-green-600 mr-2"></i>
                        <span className="text-neutral-600">{order.user?.phone}</span>
                      </div>
                      <div className="flex items-start">
                        <i className="fas fa-map-marker-alt text-red-600 mr-2 mt-1"></i>
                        <div>
                          <p className="text-neutral-900 font-medium">Yetkazish manzili:</p>
                          <p className="text-neutral-600">{order.deliveryAddress}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium text-neutral-900 mb-2">Buyurtma tafsilotlari:</h4>
                    <div className="space-y-2">
                      {order.items?.map((item: any, index: number) => (
                        <div key={index} className="flex justify-between">
                          <span>Mahsulot #{item.productId} x{item.quantity}</span>
                          <span>{item.price} so'm</span>
                        </div>
                      ))}
                      <div className="border-t pt-2 flex justify-between font-semibold">
                        <span>Jami:</span>
                        <span>{order.totalAmount} so'm</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex space-x-4">
                    {order.deliveryPersonId !== user?.id ? (
                      <Button 
                        className="bg-secondary hover:bg-green-600"
                        onClick={() => acceptOrderMutation.mutate(order.id)}
                        disabled={acceptOrderMutation.isPending}
                      >
                        <i className="fas fa-check mr-2"></i>
                        Qabul qilish
                      </Button>
                    ) : (
                      <>
                        <Button 
                          className="bg-secondary hover:bg-green-600 text-lg px-8 py-3"
                          onClick={() => updateOrderStatusMutation.mutate({ orderId: order.id, status: "delivered" })}
                          disabled={updateOrderStatusMutation.isPending}
                        >
                          <i className="fas fa-check mr-2"></i>
                          Buyurtma topshirildi
                        </Button>
                        <Button 
                          variant="destructive"
                          size="sm"
                          onClick={() => updateOrderStatusMutation.mutate({ orderId: order.id, status: "returned" })}
                          disabled={updateOrderStatusMutation.isPending}
                        >
                          <i className="fas fa-undo mr-2"></i>
                          Qaytarildi
                        </Button>
                      </>
                    )}
                    <Button 
                      variant="outline"
                      onClick={() => {
                        if (navigator.geolocation) {
                          navigator.geolocation.getCurrentPosition((position) => {
                            const { latitude, longitude } = position.coords;
                            const destination = encodeURIComponent(order.deliveryAddress);
                            window.open(`https://maps.google.com/maps?saddr=${latitude},${longitude}&daddr=${destination}`, '_blank');
                          });
                        } else {
                          const address = encodeURIComponent(order.deliveryAddress);
                          window.open(`https://maps.google.com/maps?q=${address}`, '_blank');
                        }
                      }}
                    >
                      <i className="fas fa-map-marker-alt mr-2"></i>
                      Jonli marshrut
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
            )}
          </div>

          {/* My Orders Section */}
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-neutral-900">Mening buyurtmalarim</h2>
            
            {myOrders.length === 0 ? (
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-8">
                    <i className="fas fa-truck text-4xl text-neutral-300 mb-4"></i>
                    <p className="text-neutral-500">Hozircha sizning buyurtmalaringiz yo'q</p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              myOrders.map((order: any) => (
                <Card key={order.id} className="shadow-lg border-green-200">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>Buyurtma #{order.id}</CardTitle>
                        <p className="text-neutral-600">
                          {new Date(order.createdAt).toLocaleString()}
                        </p>
                      </div>
                      <Badge className="bg-green-100 text-green-800">
                        Yetkazilmoqda
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-medium text-neutral-900 mb-2">Mijoz ma'lumotlari:</h4>
                      <div className="space-y-1">
                        <div className="flex items-center">
                          <i className="fas fa-phone text-green-600 mr-2"></i>
                          <span className="text-neutral-600">{order.user?.phone}</span>
                        </div>
                        <div className="flex items-start">
                          <i className="fas fa-map-marker-alt text-red-600 mr-2 mt-1"></i>
                          <div>
                            <p className="text-neutral-900 font-medium">Yetkazish manzili:</p>
                            <p className="text-neutral-600">{order.deliveryAddress}</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium text-neutral-900 mb-2">Buyurtma tafsilotlari:</h4>
                      <div className="space-y-2">
                        {order.items?.map((item: any, index: number) => (
                          <div key={index} className="flex justify-between">
                            <span>Mahsulot #{item.productId} x{item.quantity}</span>
                            <span>{item.price} so'm</span>
                          </div>
                        ))}
                        <div className="border-t pt-2 flex justify-between font-semibold">
                          <span>Jami:</span>
                          <span>{order.totalAmount} so'm</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex space-x-4">
                      <Button 
                        className="bg-green-600 hover:bg-green-700 text-white flex-1"
                        onClick={() => updateOrderStatusMutation.mutate({ orderId: order.id, status: "delivered" })}
                        disabled={updateOrderStatusMutation.isPending}
                      >
                        <i className="fas fa-check mr-2"></i>
                        Buyurtma topshirildi
                      </Button>
                      <Button 
                        variant="destructive"
                        onClick={() => updateOrderStatusMutation.mutate({ orderId: order.id, status: "returned" })}
                        disabled={updateOrderStatusMutation.isPending}
                      >
                        <i className="fas fa-undo mr-2"></i>
                        Qaytarildi
                      </Button>
                      <Button 
                        variant="outline"
                        onClick={() => {
                          if (navigator.geolocation) {
                            navigator.geolocation.getCurrentPosition((position) => {
                              const { latitude, longitude } = position.coords;
                              const destination = encodeURIComponent(order.deliveryAddress);
                              window.open(`https://maps.google.com/maps?saddr=${latitude},${longitude}&daddr=${destination}`, '_blank');
                            });
                          } else {
                            const address = encodeURIComponent(order.deliveryAddress);
                            window.open(`https://maps.google.com/maps?q=${address}`, '_blank');
                          }
                        }}
                      >
                        <i className="fas fa-route mr-2"></i>
                        Marshrut
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
