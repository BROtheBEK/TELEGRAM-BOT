import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Link } from "wouter";
import { useLanguage } from "@/hooks/use-language";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export default function Contact() {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);
      toast({
        title: "Xabar yuborildi",
        description: "Sizning xabaringiz qabul qilindi. Tez orada aloqaga chiqamiz."
      });
      (e.target as HTMLFormElement).reset();
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <h1 className="text-2xl font-bold text-neutral-900">Bog'lanish</h1>
            <Link href="/">
              <Button variant="outline">
                <i className="fas fa-arrow-left mr-2"></i>
                Bosh sahifa
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Contact Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Contact Information */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <i className="fas fa-phone mr-3 text-primary"></i>
                  Telefon raqamlar
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-3">
                  <i className="fas fa-phone text-green-600"></i>
                  <div>
                    <p className="font-medium">Asosiy raqam</p>
                    <p className="text-neutral-600">+998 71 123 45 67</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <i className="fas fa-mobile-alt text-green-600"></i>
                  <div>
                    <p className="font-medium">Mobil raqam</p>
                    <p className="text-neutral-600">+998 90 123 45 67</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <i className="fas fa-envelope mr-3 text-primary"></i>
                  Elektron pochta
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <i className="fas fa-envelope text-blue-600"></i>
                    <div>
                      <p className="font-medium">Asosiy email</p>
                      <p className="text-neutral-600">info@tezyetkazish.uz</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <i className="fas fa-headset text-blue-600"></i>
                    <div>
                      <p className="font-medium">Qo'llab-quvvatlash</p>
                      <p className="text-neutral-600">support@tezyetkazish.uz</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <i className="fas fa-map-marker-alt mr-3 text-primary"></i>
                  Manzil
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <i className="fas fa-building text-orange-600 mt-1"></i>
                    <div>
                      <p className="font-medium">Ofis manzili</p>
                      <p className="text-neutral-600">Toshkent shahri, Olmazor tumani<br />Buyuk Ipak Yo'li ko'chasi, 123-uy</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <i className="fas fa-clock text-orange-600"></i>
                    <div>
                      <p className="font-medium">Ish vaqti</p>
                      <p className="text-neutral-600">Dushanba - Yakshanba: 09:00 - 22:00</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <i className="fas fa-share-alt mr-3 text-primary"></i>
                  Ijtimoiy tarmoqlar
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex space-x-4">
                  <a href="#" className="flex items-center justify-center w-12 h-12 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
                    <i className="fab fa-telegram text-xl"></i>
                  </a>
                  <a href="#" className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:from-purple-600 hover:to-pink-600 transition-colors">
                    <i className="fab fa-instagram text-xl"></i>
                  </a>
                  <a href="#" className="flex items-center justify-center w-12 h-12 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                    <i className="fab fa-facebook text-xl"></i>
                  </a>
                  <a href="#" className="flex items-center justify-center w-12 h-12 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors">
                    <i className="fab fa-whatsapp text-xl"></i>
                  </a>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Contact Form */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <i className="fas fa-paper-plane mr-3 text-primary"></i>
                  Xabar yuborish
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="name">Ism va familiya</Label>
                    <Input 
                      id="name" 
                      name="name" 
                      required 
                      placeholder="Ismingizni kiriting"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="phone">Telefon raqam</Label>
                    <Input 
                      id="phone" 
                      name="phone" 
                      type="tel" 
                      required 
                      placeholder="+998 __ ___ __ __"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="email">Elektron pochta (ixtiyoriy)</Label>
                    <Input 
                      id="email" 
                      name="email" 
                      type="email" 
                      placeholder="email@example.com"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="subject">Mavzu</Label>
                    <Input 
                      id="subject" 
                      name="subject" 
                      required 
                      placeholder="Xabar mavzusi"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="message">Xabar matni</Label>
                    <Textarea 
                      id="message" 
                      name="message" 
                      required 
                      placeholder="Xabaringizni bu yerga yozing..."
                      rows={6}
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-primary hover:bg-blue-700"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <i className="fas fa-spinner fa-spin mr-2"></i>
                        Yuborilmoqda...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-paper-plane mr-2"></i>
                        Xabar yuborish
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}