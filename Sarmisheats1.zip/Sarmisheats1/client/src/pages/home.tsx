import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/navbar";
import HeroCarousel from "@/components/hero-carousel";
import ProductGrid from "@/components/product-grid";
import CartSidebar from "@/components/cart-sidebar";
import AuthModals from "@/components/auth-modals";
import ProductModal from "@/components/product-modal";
import { Card, CardContent } from "@/components/ui/card";
import { useLanguage } from "@/hooks/use-language";
import logoPath from "@assets/logo_1748530812051.png";

export default function Home() {
  const { t } = useLanguage();
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<number | null>(null);
  
  const { data: news = [] } = useQuery({
    queryKey: ["/api/news"],
  });

  return (
    <div className="min-h-screen bg-neutral-50">
      <Navbar onCartClick={() => setIsCartOpen(true)} />
      
      <HeroCarousel />
      
      <section className="py-8 sm:py-12 lg:py-16 bg-white" id="products">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 sm:mb-10 lg:mb-12">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-neutral-900 mb-3 sm:mb-4">{t('popularDishes')}</h2>
            <p className="text-base sm:text-lg lg:text-xl text-neutral-600 px-4">{t('selectDeliciousDishes')}</p>
          </div>
          
          <ProductGrid onProductClick={setSelectedProduct} />
        </div>
      </section>

      {/* Features Section */}
      <section className="py-8 sm:py-12 lg:py-16 bg-neutral-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 sm:mb-10 lg:mb-12">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-neutral-900 mb-3 sm:mb-4">{t('whyChooseUs')}</h2>
            <p className="text-base sm:text-lg lg:text-xl text-neutral-600 px-4">{t('ourAdvantages')}</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            <div className="text-center p-6 sm:p-8 bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6">
                <i className="fas fa-clock text-white text-lg sm:text-2xl"></i>
              </div>
              <h3 className="text-lg sm:text-xl font-semibold text-neutral-900 mb-3 sm:mb-4">{t('fastDelivery')}</h3>
              <p className="text-sm sm:text-base text-neutral-600">{t('fastDeliveryDesc')}</p>
            </div>

            <div className="text-center p-6 sm:p-8 bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6">
                <i className="fas fa-heart text-white text-lg sm:text-2xl"></i>
              </div>
              <h3 className="text-lg sm:text-xl font-semibold text-neutral-900 mb-3 sm:mb-4">{t('qualityFood')}</h3>
              <p className="text-sm sm:text-base text-neutral-600">{t('qualityFoodDesc')}</p>
            </div>

            <div className="text-center p-6 sm:p-8 bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow sm:col-span-2 lg:col-span-1">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6">
                <i className="fas fa-star text-white text-lg sm:text-2xl"></i>
              </div>
              <h3 className="text-lg sm:text-xl font-semibold text-neutral-900 mb-3 sm:mb-4">{t('24_7Service')}</h3>
              <p className="text-sm sm:text-base text-neutral-600">{t('24_7ServiceDesc')}</p>
            </div>
          </div>
        </div>
      </section>

      {/* News Section */}
      {news.length > 0 && (
        <section className="py-8 sm:py-12 lg:py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-8 sm:mb-10 lg:mb-12">
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-neutral-900 mb-3 sm:mb-4">{t('news')}</h2>
              <p className="text-base sm:text-lg lg:text-xl text-neutral-600 px-4">So'nggi yangiliklar va e'lonlar</p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
              {news.slice(0, 3).map((item: any) => (
                <Card key={item.id} className="overflow-hidden hover:shadow-xl transition-shadow">
                  {item.image && (
                    <img 
                      src={item.image} 
                      alt={item.title}
                      className="w-full h-48 object-cover"
                    />
                  )}
                  <CardContent className="p-6">
                    <h3 className="text-xl font-semibold text-neutral-900 mb-3">{item.title}</h3>
                    <p className="text-neutral-600 line-clamp-3">{item.content}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="bg-neutral-900 text-white py-8 sm:py-10 lg:py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            <div className="sm:col-span-2 lg:col-span-1">
              <div className="flex items-center space-x-3 mb-4 sm:mb-6">
                <img 
                  src={logoPath} 
                  alt="Sarmish Eats" 
                  className="w-8 h-8 sm:w-10 sm:h-10 object-contain"
                />
                <span className="text-lg sm:text-xl font-bold">Sarmish Eats</span>
              </div>
              <p className="text-neutral-300 text-sm sm:text-base">{t('brandDescription')}</p>
            </div>

            <div>
              <h3 className="text-base sm:text-lg font-semibold mb-3 sm:mb-4">{t('contactUs')}</h3>
              <div className="space-y-2 sm:space-y-3">
                <div className="flex items-center space-x-3">
                  <i className="fas fa-phone text-primary text-sm"></i>
                  <span className="text-sm sm:text-base">+998 71 123 45 67</span>
                </div>
                <div className="flex items-center space-x-3">
                  <i className="fas fa-envelope text-primary text-sm"></i>
                  <span className="text-sm sm:text-base">info@tezyetkazish.uz</span>
                </div>
                <div className="flex items-center space-x-3">
                  <i className="fas fa-map-marker-alt text-primary text-sm"></i>
                  <span className="text-sm sm:text-base">Toshkent, O'zbekiston</span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-base sm:text-lg font-semibold mb-3 sm:mb-4">{t('socialNetworks')}</h3>
              <div className="flex space-x-3 sm:space-x-4">
                <a href="#" className="w-8 h-8 sm:w-10 sm:h-10 bg-neutral-700 rounded-lg flex items-center justify-center hover:bg-primary transition-colors">
                  <i className="fab fa-telegram text-sm sm:text-lg"></i>
                </a>
                <a href="#" className="w-8 h-8 sm:w-10 sm:h-10 bg-neutral-700 rounded-lg flex items-center justify-center hover:bg-primary transition-colors">
                  <i className="fab fa-instagram text-sm sm:text-lg"></i>
                </a>
                <a href="#" className="w-8 h-8 sm:w-10 sm:h-10 bg-neutral-700 rounded-lg flex items-center justify-center hover:bg-primary transition-colors">
                  <i className="fab fa-facebook text-sm sm:text-lg"></i>
                </a>
              </div>
            </div>
          </div>

          <div className="border-t border-neutral-700 mt-6 sm:mt-8 pt-6 sm:pt-8 text-center">
            <p className="text-neutral-400 text-sm sm:text-base">&copy; 2024 TezYetkazish. {t('allRightsReserved')}.</p>
          </div>
        </div>
      </footer>

      <CartSidebar isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
      <AuthModals />
      {selectedProduct && (
        <ProductModal 
          productId={selectedProduct} 
          onClose={() => setSelectedProduct(null)} 
        />
      )}
    </div>
  );
}
