import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { apiRequest } from "@/lib/queryClient";

export default function Operator() {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: orders = [] } = useQuery({
    queryKey: ["/api/orders", { status: "pending" }],
    enabled: user?.role === "operator",
  });

  const acceptOrderMutation = useMutation({
    mutationFn: async (orderId: number) => {
      return apiRequest("PUT", `/api/orders/${orderId}`, {
        operatorId: user?.id,
        status: "accepted",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      toast({ title: "Buyurtma qabul qilindi", description: "Buyurtma oshpazga yetkazildi" });
    },
  });

  if (user?.role !== "operator") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6">
            <div className="text-center">
              <h1 className="text-2xl font-bold mb-4">Ruxsat berilmagan</h1>
              <p className="text-neutral-600 mb-4">Bu sahifaga kirish uchun operator huquqlari kerak</p>
              <Link href="/">
                <Button>Bosh sahifaga qaytish</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <h1 className="text-xl font-semibold text-neutral-900">Operator paneli</h1>
            <div className="flex items-center space-x-4">
              <span className="text-neutral-600">Salom, {user?.firstName || user?.phone}</span>
              <Link href="/">
                <Button variant="outline">Saytga qaytish</Button>
              </Link>
              <Button variant="ghost" onClick={logout}>Chiqish</Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-neutral-900">Yangi buyurtmalar</h2>

          {orders.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-8">
                  <i className="fas fa-clipboard-list text-4xl text-neutral-300 mb-4"></i>
                  <p className="text-neutral-500">Hozircha yangi buyurtmalar yo'q</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            orders.map((order: any) => (
              <Card key={order.id} className="shadow-lg">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle>Buyurtma #{order.id}</CardTitle>
                      <p className="text-neutral-600">
                        {new Date(order.createdAt).toLocaleString()}
                      </p>
                    </div>
                    <Badge variant="secondary">Yangi</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-medium text-neutral-900 mb-2">Mijoz ma'lumotlari:</h4>
                    <p className="text-neutral-600">Telefon: {order.user?.phone}</p>
                    <p className="text-neutral-600">Manzil: {order.deliveryAddress}</p>
                    <p className="text-neutral-600">To'lov: {order.paymentMethod === "cash" ? "Naqd" : "Karta"}</p>
                  </div>

                  <div>
                    <h4 className="font-medium text-neutral-900 mb-2">Buyurtma tafsilotlari:</h4>
                    <div className="space-y-2">
                      {order.items?.map((item: any, index: number) => (
                        <div key={index} className="flex justify-between p-2 bg-neutral-50 rounded">
                          <span className="font-medium">
                            Mahsulot #{item.productId} x{item.quantity}
                          </span>
                          <span>{item.price} so'm</span>
                        </div>
                      ))}
                      <div className="border-t pt-2 flex justify-between font-semibold text-lg">
                        <span>Jami:</span>
                        <span className="text-primary">{order.totalAmount} so'm</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4">
                    <Button 
                      className="w-full bg-primary hover:bg-blue-700 text-lg py-3"
                      onClick={() => acceptOrderMutation.mutate(order.id)}
                      disabled={acceptOrderMutation.isPending}
                    >
                      <i className="fas fa-check mr-2"></i>
                      {acceptOrderMutation.isPending ? "Qabul qilinmoqda..." : "Qabul qilish va oshpazga yuborish"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
